import tensorflow as tf
t=tf.constant([[1,2],[3,4]])
print(t)
print("Shape:",t.shape)
print("Dtype:",t.dtype)