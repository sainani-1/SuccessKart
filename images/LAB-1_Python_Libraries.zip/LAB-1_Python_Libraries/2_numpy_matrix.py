import numpy as np
A=np.array([[1,2],[3,4]])
B=np.array([[5,6],[7,8]])
print("Addition\n",A+B)
print("Subtraction\n",A-B)
print("Element-wise Multiplication\n",A*B)
print("Matrix Multiplication\n",A@B)