import pandas as pd
df=pd.DataFrame({"Name":["Alice","Bob","Charlie"],"RollNo":[101,102,103],"Marks":[85,90,78]})
print(df)
print("\nInfo:")
print(df.info())