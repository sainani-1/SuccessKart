import pandas as pd
df=pd.read_csv("students.csv")
print(df.head())
print("Rows, Columns:",df.shape)
print("Columns:",list(df.columns))
print(df.describe())