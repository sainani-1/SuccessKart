LAB-1: Introduction to Python Libraries and Basic Programs

Run:
pip install -r requirements.txt

Programs:
1_numpy_array.py
2_numpy_matrix.py
3_pandas_dataframe.py
4_pandas_csv.py
5_matplotlib_line.py
6_seaborn_heatmap.py
7_tensorflow_constant.py
8_tensorflow_variable.py
9_tensorflow_matmul.py
10_pytorch_tensor.py

Sample CSV: students.csv
