import tensorflow as tf
v=tf.Variable(5.0)
print("Initial:",v.numpy())
v.assign(10.0)
print("Updated:",v.numpy())