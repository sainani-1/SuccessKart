import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay
cm=[[50,5],[3,42]]
sns.heatmap(cm,annot=True,fmt="d",cmap="Blues",xticklabels=["Pred 0","Pred 1"],yticklabels=["Actual 0","Actual 1"])
plt.title("Confusion Matrix")
plt.show()