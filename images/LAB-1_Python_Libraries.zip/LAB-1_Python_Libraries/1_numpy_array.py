import numpy as np
arr=np.array([10,20,30,40,50])
print("Array:",arr)
print("Sum:",arr.sum())
print("Mean:",arr.mean())
print("Max:",arr.max())
print("Min:",arr.min())